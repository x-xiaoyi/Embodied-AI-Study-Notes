import cv2
import numpy as np
from collections import deque
image = cv2.imread('maze.jpg')
if image is None:
    print("The pictue was not Found")
    exit()
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
ret, binary_image = cv2.threshold(gray_image, 127, 255, cv2.THRESH_BINARY)
cv2.imwrite('gray_image.jpg', gray_image)
cv2.imwrite('binary_image.jpg', binary_image)
image = cv2.imread('maze.jpg')
print(image,np.shape)
start = (64,64)
end = (1216,1216)
dirs = [(-1,0),(1,0),(0,-1),(0,1)]
visited = [[False for _ in range(1216)]for _ in range(1216)]
parent =[[False for _ in range(1216)]for _ in range(1216)]
queue = deque()
queue.append(start)
while queue:
    x,y = queue.popleft()
    for dx,dy in dirs:
        n_x = x+dx
        n_y = y+dy
        if 0 <= n_x < 1216 and 0 <= n_y <1216 and visited[n_y][n_x] == False:
            if image[[n_y][n_x]] == 255:
                visited[n_y][n_x] = True
                parent(x,y)
                queue.append((n_y,n_x))
path = []
current = end
while current != start:
    path.append(current)
    current = parent[current[0],current[1]]
path.append(start)
path.reverse
img_path = image.copy()
for i in range(len(path-1)):
    x1,y1 = path[i]
    x2,y2 = path[i-1]
    cv2.line(img_path,(x1,y1)(x2,y2),(0,0,255),2)
cv2.imshow(img_path)
cv2.waitKey(0)





