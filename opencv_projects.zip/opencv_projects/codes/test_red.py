import cv2
import numpy as np
image = cv2.imread("../images/test_red.jpg")
if image is None:
    print("False")
else:
    print("right")
image = cv2.resize(image,(640,480))
hsv = cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
lower_red = np.array([0,100,70])
upper_red = np.array([10,120,255])
mask  = cv2.inRange(hsv,lower_red,upper_red)
cv2.imwrite("mask_image.jpg",mask)
contours,_ = cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
for cnt in contours:
    cv2.contourArea(cnt)
    x,y,w,h = cv2.boundingRect(cnt)
    cv2.rectangle(image,(x,y),(x+w,y+h),(255,0,0),3)
cv2.imwrite("new.jpg",image)


